import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

/** Mount the exported Blender scene. Call dispose() when removing the viewer. */
export async function createCanonfig(host, { autoplay = !matchMedia('(prefers-reduced-motion: reduce)').matches, onProgress = () => {}, onFrame = () => {} } = {}) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  host.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#0b1119');
  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const environment = pmrem.fromScene(room, 0.04);
  room.dispose(); pmrem.dispose();
  scene.environment = environment.texture;
  scene.environmentIntensity = 0.35;
  scene.add(new THREE.HemisphereLight(0xc9e8ff, 0x221c39, 1.1));
  function light(color, intensity, position, shadow = false) {
    const l = new THREE.DirectionalLight(color, intensity);
    l.position.set(...position); l.target.position.set(0, 2, 0);
    if (shadow) {
      l.castShadow = true; l.shadow.mapSize.set(2048, 2048);
      Object.assign(l.shadow.camera, { left: -6, right: 6, top: 7, bottom: -6, near: 0.1, far: 40 });
      l.shadow.normalBias = 0.012; l.shadow.bias = -0.00005;
    }
    scene.add(l, l.target);
  }
  light(0xffe5cb, 3.4, [-5, 10, 7], true);
  light(0xcce8ff, 1.6, [7, 5, 4]);
  light(0x85fff1, 2.6, [1, 7, -6]);
  light(0xe1d5ff, 1.2, [-5, 4, -3]);
  let gltf;
  try {
    gltf = await new GLTFLoader().loadAsync(new URL('./assets/canonfig.glb', import.meta.url).href, e => onProgress(e.total ? e.loaded / e.total : 0));
  } catch (error) {
    environment.dispose(); renderer.dispose(); renderer.domElement.remove(); throw error;
  }
  scene.add(gltf.scene); gltf.scene.updateMatrixWorld(true);
  gltf.scene.traverse(o => {
    if (o.isMesh) { o.castShadow = !o.name.startsWith('End_particle'); o.receiveShadow = true; }
  });
  const camera = gltf.cameras[0];
  if (!camera?.isOrthographicCamera) throw new Error('The exported orthographic camera is missing.');
  const initialPosition = camera.position.clone();
  const initialQuaternion = camera.quaternion.clone();
  const controls = new OrbitControls(camera, renderer.domElement);
  const target = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion).multiplyScalar(17).add(camera.position);
  controls.target.copy(target); controls.enableDamping = true; controls.enablePan = false;
  controls.minZoom = 0.65; controls.maxZoom = 2.5;
  controls.minPolarAngle = 0.15; controls.maxPolarAngle = Math.PI * 0.49;
  controls.update();
  const mixer = new THREE.AnimationMixer(gltf.scene);
  for (const clip of gltf.animations) mixer.clipAction(clip).play();
  const duration = Math.max(...gltf.animations.map(a => a.duration));
  let playing = autoplay, time = 0, last = performance.now(), disposed = false;
  const composer = new EffectComposer(renderer);
  const ao = new SSAOPass(scene, camera, 1, 1);
  ao.kernelRadius = 0.28; ao.minDistance = 0.001; ao.maxDistance = 0.08;
  composer.addPass(ao);
  const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.18, 0.3, 1.8);
  composer.addPass(bloom); composer.addPass(new OutputPass());
  function resize() {
    const width = Math.max(1, host.clientWidth), height = Math.max(1, host.clientHeight);
    const aspect = width / height, halfHeight = 5.42305 * Math.max(1, 0.9 / aspect);
    camera.left = -halfHeight * aspect; camera.right = halfHeight * aspect;
    camera.top = halfHeight; camera.bottom = -halfHeight; camera.updateProjectionMatrix();
    renderer.setSize(width, height); composer.setSize(width, height);
  }
  const observer = new ResizeObserver(resize); observer.observe(host); resize();
  renderer.setAnimationLoop(now => {
    if (disposed) return;
    const dt = Math.min((now - last) / 1000, 0.05); last = now;
    if (playing && !document.hidden) time = (time + dt) % duration;
    mixer.setTime(time); controls.update(); composer.render(); onFrame(time / duration);
  });
  return {
    scene, camera, renderer, mixer, duration,
    get playing() { return playing; },
    play() { playing = true; }, pause() { playing = false; },
    seek(fraction) { time = THREE.MathUtils.clamp(fraction, 0, 0.999999) * duration; mixer.setTime(time); },
    reset() { time = 0; camera.position.copy(initialPosition); camera.quaternion.copy(initialQuaternion); camera.zoom = 1; camera.updateProjectionMatrix(); controls.target.copy(target); controls.update(); },
    dispose() {
      disposed = true; renderer.setAnimationLoop(null); observer.disconnect(); controls.dispose(); mixer.stopAllAction(); mixer.uncacheRoot(gltf.scene);
      const materials = new Set(), textures = new Set();
      gltf.scene.traverse(o => { if (o.isMesh) { o.geometry.dispose(); for (const m of Array.isArray(o.material) ? o.material : [o.material]) materials.add(m); } });
      for (const m of materials) { for (const value of Object.values(m)) if (value?.isTexture) textures.add(value); m.dispose(); }
      for (const texture of textures) texture.dispose();
      scene.traverse(o => { if (o.isLight) o.shadow?.dispose(); });
      for (const pass of composer.passes) pass.dispose?.();
      composer.dispose(); environment.dispose(); renderer.dispose(); renderer.domElement.remove();
    }
  };
}
