import { createCanonfig } from './scene.js';
const status = document.querySelector('#status');
const play = document.querySelector('#play'), timeline = document.querySelector('#timeline'), reset = document.querySelector('#reset');
try {
  const viewer = await createCanonfig(document.querySelector('#scene'), {
    onProgress: n => { status.textContent = n ? `Loading scene… ${Math.round(n * 100)}%` : 'Loading scene…'; },
    onFrame: n => { timeline.value = Math.round(n * 1000); }
  });
  status.hidden = true;
  for (const element of [play, timeline, reset]) element.disabled = false;
  function sync() { play.textContent = viewer.playing ? 'Pause' : 'Play'; play.setAttribute('aria-label', viewer.playing ? 'Pause animation' : 'Play animation'); }
  sync();
  play.onclick = () => { viewer.playing ? viewer.pause() : viewer.play(); sync(); };
  timeline.oninput = () => { viewer.pause(); viewer.seek(Number(timeline.value) / 1000); sync(); };
  reset.onclick = () => { viewer.reset(); };
  window.addEventListener('pagehide', () => viewer.dispose(), { once: true });
  // Exposed for host-page integrations and diagnostics.
  window.canonfig = viewer;
} catch (error) {
  console.error(error); status.textContent = 'Unable to load the 3D scene. Use a WebGL2 browser and serve these files over HTTP.';
}
