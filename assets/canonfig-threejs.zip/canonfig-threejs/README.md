# Canonfig · Three.js scene

A real-time conversion of the revised Blender scene: enlarged, settled logo pile, recessed hollow lid, pixel-textured Ender Chest, and animated purple particles.

## Host it immediately

Upload the **contents of `dist/`** to any static web host. Keep the `assets/` folder beside `index.html`. Everything required at runtime is bundled locally; there are no CDN or backend dependencies. Relative URLs support hosting in a subdirectory.

To preview the already-built version locally:

```sh
python -m http.server 8000 --directory dist
```

Open http://localhost:8000. Serve it over HTTP/HTTPS, not by double-clicking the HTML file.

To embed the hosted viewer in another page:

```html
<iframe
  src="/canonfig/index.html"
  title="Interactive Canonfig chest"
  style="width:100%;height:640px;border:0;border-radius:16px"
  loading="lazy"
></iframe>
```

## Edit the source

Use Node.js 22.12+ or 24 LTS.

```sh
npm ci
npm run dev
# After editing:
npm run build
```

- `scene.js`: reusable Three.js scene, lighting, camera, postprocessing, and animation.
- `main.js`: connects the scene to the viewer controls.
- `index.html`: layout and styling.
- `assets/canonfig.glb`: embedded texture, mesh geometry, orthographic camera, and one synchronized animation clip.
- `dist/`: built website ready for upload.

Mount the scene in an existing Vite/bundler project after installing the pinned Three.js dependency. Copy `scene.js` and `assets/canonfig.glb` together, keeping their relative paths:

```js
import { createCanonfig } from './scene.js';
const viewer = await createCanonfig(document.querySelector('#scene'));
viewer.pause();
viewer.seek(0); // open, initial pose; fraction of the six-second loop
viewer.play();
// When unmounting:
// viewer.dispose();
```

The container must have a nonzero CSS height, for example `height: 600px`. `createCanonfig` accepts `autoplay`, `onProgress(fraction)`, and `onFrame(fraction)`. It returns `play()`, `pause()`, `seek(fraction)`, `reset()`, `dispose()`, and scene/camera/renderer/mixer references. The included page also exposes the instance as `window.canonfig`.

## Included behavior

- Continuous 360° rotation, lid opening/closing, and particles in a six-second loop.
- Drag to orbit, scroll/pinch to zoom, pause/play, timeline, and reset view.
- Responsive orthographic framing and a maximum pixel ratio of 2.
- Reduced-motion preference disables autoplay initially.
- Real-time PBR lighting, shadow mapping, screen-space ambient occlusion, and subtle emissive bloom.
- No generated white logo backing plates; the actual modeled pieces are retained.

WebGL2 is required. This uses real-time rendering rather than Cycles, so lighting and reflections will differ from the Blender PNG/GIF. For lower-powered devices, reduce pixel ratio, shadow resolution, or remove the SSAO/bloom passes in `scene.js`.

## Validation

Production build succeeded. Khronos glTF Validator: 0 errors and 0 warnings (unused UV informational notices only). Three.js GLTFLoader/AnimationMixer checks passed: 111 mesh objects, 20 particles, 62 animation tracks, 6-second duration, lid opening/closing, rotation, particle motion, and loop continuity. Texture pixels are embedded in the GLB. Node animation checks used a texture-image stand-in because Node has no browser image decoder.

A browser could not be launched in the creation environment, so the final WebGL appearance and interactive controls have not been visually browser-tested. The original Blender render is not presented as a screenshot of this viewer.

## Attribution

The Three.js MIT license is included in `THREE-LICENSE.txt`. Original asset/source notes are in `sources.txt`. Minecraft assets and provider marks belong to their respective owners; this conversion does not grant additional rights to those marks or textures.

Three.js references: https://threejs.org/docs/pages/GLTFLoader and https://threejs.org/manual/pages/animation-system.html
